export class Heroe{
    name : string;
    description : string;
    pictures : [];
}